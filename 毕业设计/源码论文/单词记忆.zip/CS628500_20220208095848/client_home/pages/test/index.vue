<template>
	<view id="test">
		<!-- XXX模块(开始) -->
		<mm_warp id="">
			<mm_container>
				<mm_row>
					<mm_col class="col-12 col-sm-6 col-md-4">
						<mm_view class="yyy">
							1111
						</mm_view>
					</mm_col>
				</mm_row>
			</mm_container>
		</mm_warp>
		<!-- XXX模块(结束) -->
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		components: {
		}
	}
</script>

<style>
	.mm_warp {
		background-color: red;
	}
</style>
