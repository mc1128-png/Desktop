<template>
	<view class="mm_main">
		<slot></slot>
	</view>
</template>

<script>
	export default {};
</script>

<style>
</style>
