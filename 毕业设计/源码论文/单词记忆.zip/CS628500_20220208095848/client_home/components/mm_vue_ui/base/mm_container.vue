<template>
	<view class="mm_container">
		<slot></slot>
	</view>
</template>

<script>
	export default {};
</script>

<style>
</style>
