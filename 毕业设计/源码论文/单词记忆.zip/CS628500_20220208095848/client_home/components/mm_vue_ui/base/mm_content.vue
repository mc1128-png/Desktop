<template>
	<view class="mm_content">
		<slot></slot>
	</view>
</template>

<script>
	export default {
		props: {}
	};
</script>

<style>
</style>
