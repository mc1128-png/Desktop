<template>
  <footer class="mm_foot"><slot></slot></footer>
</template>

<script>
</script>

<style>
</style>
