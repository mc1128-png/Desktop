<template>
	<view class="mm_body"><slot></slot></view>
</template>

<script>
	export default {
		
	};
</script>

<style>
</style>
