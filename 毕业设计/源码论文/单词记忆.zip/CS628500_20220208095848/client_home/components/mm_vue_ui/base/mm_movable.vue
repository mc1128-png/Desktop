<template>
	<view class="mm_movable">
		<slot></slot>
	</view>
</template>

<script>
	export default {};
</script>

<style>
</style>
