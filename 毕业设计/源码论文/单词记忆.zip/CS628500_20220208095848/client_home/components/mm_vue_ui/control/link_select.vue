<template>
	<!-- 联动选择器 -->
	<div class="control_link_select">
	</div>
</template>

<script>
	export default {
		props: {
		}
	}
</script>

<style>
</style>
