module.exports = {
	db: "mysql",
	web: {
		port: 5000,
		host: "0.0.0.0"
	},
	mysql: {
		host: "127.0.0.1",
		user: "root",
		password: "root",
		database: "CS628500_20220208095848",
		log: false,
		timezone:"08:00"
	}
}